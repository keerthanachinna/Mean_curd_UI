import { Component, OnInit } from '@angular/core';
import { EmployeeService} from '../shared/employee.service';
import { NgForm } from '@angular/forms';
import {Employee} from '../shared/employee.model';

declare var M:any;
@Component({
  selector: 'app-employee',
  templateUrl: './employee.component.html',
  styleUrls: ['./employee.component.css'],
  providers:[EmployeeService]
})
export class EmployeeComponent implements OnInit {
  employeelist:any[];
  constructor( private employeeService:EmployeeService ) { }

  ngOnInit() {
    this.resetForm();
this.refreshEmployeeList();
  }
  resetForm(form?:NgForm){
  if(form)
  form.reset();
  this.employeeService.selectEmployee={
    _id:"",
    name:"",
    position:"",
    office:"",
    salary:null
  
  }
}
onSubmit(form:NgForm){
  
  if(form.value._id == ""){
  this.employeeService.postemployee(form.value).subscribe((res)=>{
    this.resetForm(form);
  this.refreshEmployeeList();
    M.toast({html: 'saved successfully',classes:'rounded'})
  });
  }else{
    this.employeeService.putEmployee(form.value).subscribe((res)=>{
    this.resetForm(form);
  this.refreshEmployeeList();
    M.toast({html: 'update successfully',classes:'rounded'})
  });
  }
}
refreshEmployeeList(){
  this.employeeService.getEmployeeList().subscribe((res)=>{
    this.employeeService.employees=res as Employee[];
   this.employeelist= this.employeeService.employees;
    console.log("this.employeeService.employees.............",this.employeeService.employees)
    console.log("this.employeelist..............",this.employeelist)
    
  });
  
}
onEdit(emp:Employee){
this.employeeService.selectEmployee=emp;
}
onDelete(_id:string,form:NgForm){
if(confirm(' r u sure dlete '+_id)==true){
  this.employeeService.deleteEmployee(_id).subscribe((res)=>{

    this.resetForm(form);
  this.refreshEmployeeList();
  M.toast({html: 'deleted successfully',classes:'rounded'})
    
  })
}
}

}
