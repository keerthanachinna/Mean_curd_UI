import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
// import { Map } from 'rxjs/operator/map';
import 'rxjs/operator/toPromise';

import {Employee } from './employee.model';

@Injectable({
  providedIn: 'root'
})
export class EmployeeService {
  selectEmployee:Employee;
  employees:Employee[];
readonly baseUrl='http://localhost:3000/employee';
// readonly baseUrll='http://localhost:3000/employee/list';


  constructor( 
    private http :HttpClient
  ) { }
  postemployee (emp:Employee){
return this.http.post(this.baseUrl,emp);
  }
  getEmployeeList(){
   return this.http.get(this.baseUrl); 
  }
  putEmployee(emp:Employee){
    return this.http.put(this.baseUrl+ `/${emp._id}`,emp);
  }
  deleteEmployee(_id:string){
    return this.http.delete(this.baseUrl+`/${_id}`)
    // return this.http.delete(this.baseUrl+`/${_id}`);
    
  }
}
