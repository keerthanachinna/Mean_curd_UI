export class Employee {
    _id:string;
    name:string;
    office:string;
    position:string;
    salary:number
}
