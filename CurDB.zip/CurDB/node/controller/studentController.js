const express = require('express');
var router = express.Router();


var  { Student }  = require('../models/student');
//localhost:3000/student/list

module.exports = router;