
const express=require('express');
// const mongoose=require('mongoose');
// const cores=required('cours');
const bodyParser=require('body-parser');
const cours=require('cors');

const { mongoose } =require('./db.js');
var employeeContoller=require('./controller/employeeController.js')
var studentContoller=require('./controller/studentController.js')
 var app=express();

 app.use(bodyParser.json());
 
 app.use(cours({origin:'http://localhost:4200'}));

 app.listen(3000,()=>console.log('server started at port:3000'))

 app.use('/employee',employeeContoller);
 app.use('/student',studentContoller);
 
