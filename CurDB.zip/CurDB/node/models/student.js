const mongoose=require('mongoose');

var Student=mongoose.model('Student',{
    name:{type:String},
    poastion:{type:String},
    
},'std');
module.exports=Student;